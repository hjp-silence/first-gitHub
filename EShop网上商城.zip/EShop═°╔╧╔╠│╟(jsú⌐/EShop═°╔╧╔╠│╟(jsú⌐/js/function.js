function addFav(id) {
  // $.ajax({})
  $.alert({
    content: '已成功加入收藏夹'
  })
  return false
}

function queryForm() {
  $.confirm({
    title: '进度查询',
    content: '' +
      '<form action="query.php" class="queryForm" method="GET">' +
      '<div class="form-group">' +
      '<p><input type="text" placeholder="请输入会员账号" class="name form-control" name="username" required /></p>' +
      '</div>' +
      '</form>',
    buttons: {
      ok: {
        text: '提交',
        btnClass: 'btn-blue',
        action: function () {
          var name = this.$content.find('.name').val();
          if (!name) {
            $.alert('请输入正确的会员账号');
            return false;
          }
          $.alert('Your name is ' + name);
          $('.queryForm')[0].submit()
        }
      },
      cancel: {
        text: '取消',
        action: function () {
          //close，
        }
      },
    },
    onContentReady: function () {
      // bind to events
      var jc = this;
      this.$content.find('form').on('submit', function (e) {
        // if the user submits the form by pressing enter in the field.
        e.preventDefault();
        jc.$$formSubmit.trigger('click'); // reference the button and click it
      });
    }
  });
}

function showMenu() {
  $('#mask,#menu').toggleClass('show')
}

function payOrder() {
  //这里放提交订单的转向
  location.href = './pay_upload.htm'
}

function customerReply(avatar) {
  var content = $('#reply').val()
  var innerHtml = '<dl class="user">'
  innerHtml += '<dt>'
  innerHtml += '<span>'
  innerHtml += '<img src="' + avatar + '" alt="">'
  innerHtml += '</span>'
  innerHtml += '</dt>'
  innerHtml += '<dd>'
  innerHtml += '<p class="text">' + content + '</p>'
  innerHtml += '</dd>'
  innerHtml += '</dl>'
  if (!content) {
    $.alert('发送内容不能为空')
  } else {
    //此处模拟AJAX上传聊天记录
    setTimeout(function () {
      $('#chat_box').append(innerHtml)
      $('#reply').val('')
      $('#chat_box').scrollTop($('#chat_box')[0].scrollHeight);
    }, 1000)
  }
}

function imgReply(avatar) {
  var pic = document.getElementById('img_reply').files[0];
  var sr = window.URL.createObjectURL(pic);
  var innerHtml = '<dl class="user">'
  innerHtml += '<dt>'
  innerHtml += '<span>'
  innerHtml += '<img src="' + avatar + '" alt="">'
  innerHtml += '</span>'
  innerHtml += '</dt>'
  innerHtml += '<dd>'
  innerHtml += '<p class="text"><img src="' + sr + '"?></p>'
  innerHtml += '</dd>'
  innerHtml += '</dl>'
  $('#chat_box').append(innerHtml)
  $('#reply').val('')
  //此处模拟AJAX上传图片
  setTimeout(function () {
    $('#chat_box').scrollTop($('#chat_box')[0].scrollHeight);
  }, 1000)

}

function lvlUp(num) {
  $.confirm({
    content: '您可以升级到' + num + '级会员<br>是否现在升级？',
    buttons: {
      ok: {
        text: '确定',
        action: function () {
          location.href = "lvl_up.htm"
        }
      },
      cancel: {
        text: '取消'
      }
    }
  })
}

function viewLvl(num) {
  $.dialog({
    content: '业绩累计销售额7000直接晋升至V4',
  })
}

function payWxZfb() {
  $.confirm({
    content: '<span>收款人：丁湘红</span><span class="seprarate"></span><span>账号:18621186961</span><br>支付后请保留支付截屏，并上传商家确认',
    buttons: {
      ok: {
        text: '支付完毕',
        action: function () {
          payOrder()
        }
      },
      close: {
        text: '取消'
      }
    }
  })
}

function payQrcode() {
  $.confirm({
    content: '<p style="text-align:center"><img src="./images/qrcode.png" style="width:50vw"></p>',
    buttons: {
      ok: {
        text: '支付完毕',
        action: function () {
          payOrder()
        }
      },
      close: {
        text: '取消'
      }
    }
  })
}

function payBank() {
  $.confirm({
    content: '开户行：工商银行 <br>银行账号：<span class="red">6000 0048 5524 358</span><br>支付后请保留支付截屏，并上传商家确认',
    buttons: {
      ok: {
        text: '支付完毕',
        action: function () {
          payOrder()
        }
      },
      close: {
        text: '取消'
      }
    }
  })
}

function payCash() {
  $.confirm({
    content: '支付后请保留支付截屏，并上传商家确认',
    buttons: {
      ok: {
        text: '支付完毕',
        action: function () {
          payOrder()
        }
      },
      close: {
        text: '取消'
      }
    }
  })
}

function payUpload() {
  $('#upload_file').click()
}

function uploadFile() {
  //upload Ajax here
  $.alert({
    autoClose: 'ok|5000',
    content: '上传中，请稍后...',
    buttons: {
      ok: {
        text: '取消',
        action: function () {
          $.alert({
            content: '上传成功',
            onDestroy: function () {
              location.href='./panel.htm'
            },
          });
        }
      }
    }
  })
}

function getUrlParam(name) {
 var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
 var r = window.location.search.substr(1).match(reg); //匹配目标参数
 if (r != null) return unescape(r[2]); return null; //返回参数值
}