
jconfirm.defaults = {
  title: '提示',
  titleClass: '',
  useBootstrap: false,
  boxWidth: '90vw',
  bgOpacity: '.6',
  animateFromElement: false,
  animation: 'top',
  closeAnimation: 'bottom',
  theme: 'se7en',
  backgroundDismiss: true,
  buttons: {
    ok: {
      text: '确定'
    }
  }
}

$(document).ready(function () {
  var mySwiper = new Swiper ('#slider .swiper-container', {
    loop: true, // 循环模式选项
    // 如果需要分页器
    pagination: {
      el: '.swiper-pagination',
    },
  })      
  var productGallery = new Swiper ('#product_gallery .swiper-container', {
    loop: true, // 循环模式选项
    // 如果需要分页器
    pagination: {
      el: '.swiper-pagination',
    },
  })
  $('.gate_list dl').click(function(){
    $('.gate_list dl').removeClass('active')
    $(this).addClass('active')
  })
  $('#upload_file').on('change',function(){
    uploadFile()
  })     
 
});
