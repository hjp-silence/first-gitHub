// JavaScript Document
 function myCartGoods()
 {
	 this.goodsid = 0;
	 this.goodsname = "";
	 this.goodsimg = "";
	 this.goodsprice = 0;
	 this.sellsum = 0;
 }

 function myCart()
 {
	 //购物车商品
	 this.goodslist = this.getGoodsListFromCookie(); //new Array();
 }
 myCart.prototype = 
 {
	 constructor:myCart,
	
	 //判断COOKIE是否可用
	cookieIsEnable: function()
	{
		$.cookie('test_cookie', 'enable');
  		var x  = $.cookie('test_cookie');
		if(x == 'enable')
		{
			return true;
		}
		else
		{ 
			return false;
		}
	},	
	 //新增商品
	 addNew:function(id,name,img,price)
	 {
		 var goods  = new myCartGoods();
		 goods.goodsid = id;
		 goods.goodsimg = img;
		 goods.goodsname = name;
		 goods.goodsprice = price;
		 goods.sellsum = 1;
		 
		 var pos = this.getGoodsPosById(id);
		 if(pos < 0)
		 {
		 	this.goodslist.push(goods);
		 	this.saveGoodsListToCookie();
		 }
	 },
	 
	 //增加商品
	 add:function(id)
	 {
		 var pos = this.getGoodsPosById(id);
		 if(pos >= 0)
		 {
			 this.goodslist[pos].sellsum++;
		 }
		 
		 this.saveGoodsListToCookie();
		 
		 return this.goodslist[pos].sellsum;
	 },
	 //减少商品
	 dec:function(id)
	 {
		var pos = this.getGoodsPosById(id);
		if(pos >= 0)
		{
			this.goodslist[pos].sellsum--;
		} 
		
		if(this.goodslist[pos].sellsum <=0)
		{//移除商品
			this.goodslist.splice(pos,1);
			
			this.saveGoodsListToCookie();
			
			return 0;
		}
		else
		{
			this.saveGoodsListToCookie();
			
			return this.goodslist[pos].sellsum;
		}
	 },
	 //获取商品总价格
	 getSellPriceSum: function()
	 {
		 var sellsum = 0;
		 for(var i = 0; i< this.goodslist.length; i++)
		 {
			 sellsum = sellsum*1 + this.goodslist[i].goodsprice * this.goodslist[i].sellsum * 0.8;
			 sellsum = sellsum.toFixed(2);
		 }
		 return sellsum;
	 },
	 
	 //获取某一个编号的商品在购物车中的位置
	 getGoodsPosById: function(id)
	 {
		for(var i = 0; i <　this.goodslist.length; i++) 
		{
			if(this.goodslist[i].goodsid == id)
			{
				return i;
			}
		}
		return -1;
	 },
	 
	 //将购物车货物保存到 COOKIE
	 saveGoodsListToCookie:function()
	 {
		 $.cookie('goodslist',JSON.stringify(this.goodslist));
	 },
	 
	 //COOKIE取出购物车货物列表
	 getGoodsListFromCookie:function()
	 {
		 var list = $.cookie('goodslist');
		 if(list == undefined || list == null)
		 {
			 list = new Array();
		 }
		 else
		 {
			 list = JSON.parse(list);
		 }
		 return list;
	 },
 }