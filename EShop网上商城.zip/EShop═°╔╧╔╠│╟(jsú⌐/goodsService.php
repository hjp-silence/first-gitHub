<?php include_once("./mysqli.php"); ?>
<?php include_once("./cartGoods.php"); ?>
<?php include_once("./myCart.php"); ?>
<?php
$rs = Query("select * from tbl_goods");
echo json_encode($rs);
?>