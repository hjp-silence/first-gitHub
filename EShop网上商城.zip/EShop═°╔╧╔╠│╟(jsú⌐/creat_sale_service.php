<?php	
ini_set("session.use_trans_sid","1");
ini_set("session.use_only_cookies",0);
ini_set("session.use_cookies",1);
session_start();	
?>
<?php include_once("./mysqli.php"); ?>
<?php include_once("./cartGoods.php"); ?>
<?php include_once("./myCart.php"); ?>
<?php
	$_SESSION["userid"] = 1;

	//获取浏览器端传入的数据
	$goodsstr =  $_POST["data"];
	
	$goodslist = json_decode($goodsstr,true);
	
	$cart1 = new myCart();
	
	for($i = 0; $i < count($goodslist); $i++)
	{
		$temp = new cartGoods();
		$temp->GOODS_ID = $goodslist[$i]["goodsid"];
		$temp->GOODS_NAME = $goodslist[$i]["goodsname"];
		$temp->GOODS_PRICE = $goodslist[$i]["goodsprice"];
		$temp->GOODS_IMAGE_URL = $goodslist[$i]["goodsimg"];
		$temp->sell_sum = $goodslist[$i]["sellsum"];
		
		$cart1->add($temp,true);
	}
	//判断用户是否登录
	
	//判断购物车里面是否有货物,没有回首页
	//$cart1 = new myCart();
	if($cart1->getPaySum() >0)
	{
		$conn = getConn();//获取数据库连接，因为事物必须在同一个数据库连接上执行
		
		mysqli_autocommit($conn,false);// 开始事务
		//有货物写订单
		execSql1("insert tbl_sales (BUY_USER_ID,SALE_PRICE_SUM) values (1,".$cart1->getPaySum().")",$conn);
		//获取订单编号
		$temp = Query1("select  @@IDENTITY as id,0 as tt",$conn);
			
		if(count($temp) == 1)
		{
			$saleid = $temp[0]["id"];
			if($saleid > 0)
			{
				$err = true;
				//写订单货物
				for($i = 0; $i <count($cart1->_goodsList); $i++)
				{
					$sql = "insert tbl_sale_goods (GOODS_ID,SALE_ID,GOODS_NAME,GOODS_PRICE,GOODS_IMAGE_URL,SELL_SUM,GOODS_SELL_PRICE) values (".$cart1->_goodsList[$i]->GOODS_ID.",".$saleid.",'".$cart1->_goodsList[$i]->GOODS_NAME."',".$cart1->_goodsList[$i]->GOODS_PRICE.",'".$cart1->_goodsList[$i]->GOODS_IMAGE_URL."',".$cart1->_goodsList[$i]->sell_sum.",".$cart1->_goodsList[$i]->GOODS_PRICE*0.8.")";
					$err = execSql1($sql,$conn);
				
					if(!$err)//如果出错
					{
							
					var_dump($sql);
						break;
					}
				}
				
				if($err)
				{
					mysqli_commit($conn);
					mysqli_close($conn);
					$cart1->clearCart();
					echo "OK";//转到订单列表页面
				}
				else
				{
					mysqli_rollback($conn);
					mysqli_close($conn);
					echo "<script>alert('记录货物失败，请重试！');location.href='cart.php'</script>";
				}
				
			}
			else
			{
				mysqli_rollback($conn);
				mysqli_close($conn);
				
				echo "<script>alert('下订单失败1，请重试！');location.href='cart.php'</script>";
			}
		}
		else
		{
			mysqli_rollback($conn);
			mysqli_close($conn);
			echo "<script>alert('下订单失败，请重试！');location.href='cart.php'</script>";
		}
	
	}
	else
	{
		echo "<script>alert('购物车为空！');location.href='index.php'</script>";
	}

?>