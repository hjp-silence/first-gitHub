﻿<?php
/**
 * MySQLi.php
 */
 
/**
 * db_con
 *
 * 创建SqlServer连接。
 * 使用MySQLi连接方式。
 */
function db_con()
{
    $servername = 'localhost';
    $username = 'root'; //数据库用户名
    $password = '';   //数据库密码
	
    $database = 'eshop';     //数据库

    // 创建连接
	$con = new mysqli($servername, $username, $password, $database);
		mysqli_set_charset($con, "utf8");
    if ($con)
        return $con;
    return null;
}
 
/**
 * db_query
 * 执行select语句，返回二维数组(含字段)，参考test.php。
 */
function db_query($sql)
{
    $con = db_con();
    if (is_null($con))
        return null;
 
    $rs = mysqli_query($con, $sql);
 
    if( $rs === false) {
        //echo 'sql error : ' . $sql;
        //exit;
    }
 
    $table = array();
 
    if( $rs === false || mysqli_num_rows($rs) == 0 ) {
        return $table;
    }
	
	$rowname = array();
 	 while($fieldinfo = mysqli_fetch_field($rs))
	 {
  		$rowname[] = $fieldinfo->name;
	 }
    while ($trow = mysqli_fetch_assoc($rs)) {
        $row =  array();

        foreach($rowname as $name) {
            $row[$name] = characet($trow[$name]);
			
        }
        $table[] = $row;
    }
 
    if( count($table) > 0  ) {
        mysqli_free_result($rs);
    }
 
    mysqli_close($con);
 
    return $table;
}
 
/**
 * mysqli_execute
 * 执行insert，update或delete语句。
 * 如果执行不成功，调整一下数据库参数和mysqli_connect参数。
 */
function db_exec($sql)
{
    $con = db_con();
    if (is_null($con))
        return null;
    $dat = mysqli_query($con, $sql);
    mysqli_close($con);
    return $dat;
}

function characet($data){
  if( !empty($data) ){
    $fileType = mb_detect_encoding($data , array('UTF-8','GBK','LATIN1','BIG5')) ;
    if( $fileType != 'UTF-8'){
      $data = mb_convert_encoding($data ,'UTF-8' , $fileType);
    }
  }
  return $data;
}
?>