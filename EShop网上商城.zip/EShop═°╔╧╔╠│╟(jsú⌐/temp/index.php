<!DOCTYPE html>
<html>

<head>

</title>
  <meta charset="utf-8">
  <meta name="renderer" content="webkit" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1, user-scalable=no"
    name="viewport" />
  <meta name="apple-touch-fullscreen" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="full-screen" content="yes" />
  <meta name="x5-fullscreen" content="true" />
  <meta name="screen-orientation" content="portrait" />
  <meta name="x5-orientation" content="portrait" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="theme-color" content="#4c516a" />
  <meta name="format-detection" content="telephone=no" />
  <meta name="format-detection" content="email=no" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="MobileOptimized" content="320" />
  <meta name="screen-orientation" content="portrait" />
  <meta name="x5-orientation" content="portrait" />
  <meta name="full-screen" content="yes" />
  <meta name="x5-fullscreen" content="true" />
  <meta name="browsermode" content="application" />
  <meta name="x5-page-mode" content="app" />
  <meta name="msapplication-tap-highlight" content="no" />
  <link rel="icon" href="data:image/ico;">
  <!-- CSS -->
  <link rel="stylesheet" href="./css/jquery-confirm.min.css">
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/swiper.min.css">
  <link rel="stylesheet" href="./css/icon/iconfont.css">
  <link rel="stylesheet" href="./css/layout.css">
  <?php
  include_once("MySQLi.php");
?>
</head>

<body>
  <title><?php
  /*
$servername = "localhost";
$username = "root";
$password = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password);
 
// 检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
echo "连接成功";
*/
$resault = db_query("select * from tbl_goods");
var_dump($resault);
echo $resault[0]["goods_name"];
?>
</title>
  <div id="mask">
    <div class="background" onclick="showMenu()"></div>
  </div>
  <div id="top">
    <div class="w640">
      <div class="title">
        <dl class="search">
          <dt><i class="iconfont icon-search"></i></dt>
          <dd><input type="text" placeholder="神经酸润眼液"></dd>
        </dl>
      </div>
      <div class="icon_link left">
        <a href="javascript:showMenu()">
          <i class="iconfont icon-menu_learn"></i>
        </a>
      </div>
      <div class="icon_link right">
        <a>
          <i class="iconfont icon-scan"></i>
        </a>
      </div>
      <div id="menu">
        <ul>
          <li><a href="./panel.htm"><i class="iconfont icon-live_me"></i>用户中心</a></li>
          <li><a href="./register.htm"><i class="iconfont icon-invite_friends"></i>注册账号</a></li>
          <li><a href="./address.htm"><i class="iconfont icon-location"></i>收货地址</a></li>
          <li><a href="./message.htm"><i class="iconfont icon-message_learn"></i>站内消息</a></li>
          <li><a href="order_list.htm"><i class="iconfont icon-means"></i>订单管理</a></li>
          <li><a href="./customer.htm"><i class="iconfont icon-customer"></i>客户服务</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div id="app">
    <div id="slider">
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><img src="./images/banner.png" alt=""></div>
          <div class="swiper-slide"><img src="./images/banner.png" alt=""></div>
          <div class="swiper-slide"><img src="./images/banner.png" alt=""></div>
          <div class="swiper-slide"><img src="./images/banner.png" alt=""></div>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <div id="quick_menu">
      <a href="">
        <dl>
          <dt><i class="iconfont icon-my_meetings"></i></dt>
          <dd>人员管理</dd>
        </dl>
      </a>
      <a href="">
        <dl>
          <dt><i class="iconfont icon-ticket"></i></dt>
          <dd>优惠券</dd>
        </dl>
      </a>
      <a href="">
        <dl>
          <dt><i class="iconfont icon-collect_line"></i></dt>
          <dd>收藏夹</dd>
        </dl>
      </a>
      <a href="">
        <dl>
          <dt><i class="iconfont icon-jifen"></i></dt>
          <dd>积分管理</dd>
        </dl>
      </a>
    </div>
    <div id="index_ad">
      <a href=""><img src="./images/ad1.png" alt=""></a>
      <a href=""><img src="./images/ad2.png" alt=""></a>
    </div>
    <h1 class="title">
      <b>Recogment</b>
      <span>推荐商品</span>
    </h1>
    <div class="product_list_box">
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
    </div>
    <h1 class="title no_top">
      <b>Hot sale</b>
      <span>热销商品</span>
    </h1>
    <div class="product_list_box">
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
      <dl>
        <a href="./product.htm">
          <dt><img src="./images/product.png" alt=""></dt>
          <dd>
            <span class="name">神经酸润眼液</span>
            <span class="red">￥96.32</span>
          </dd>
        </a>
      </dl>
    </div>
  </div>
  <div id="nav">
    <div class="w640">
      <dl class="active">
        <a href="./index.htm">
          <dt><i class="iconfont icon-home_line"></i></dt>
          <dd>首页</dd>
        </a>
      </dl>
      <dl>
        <a href="./cart.htm">
          <dt><i class="iconfont icon-cart"></i></dt>
          <dd>购物车</dd>
        </a>
      </dl>
      <dl>
        <a href="./order_list.htm">
          <dt><i class="iconfont icon-means"></i></dt>
          <dd>订单</dd>
        </a>
      </dl>
      <dl>
        <a href="./panel.htm">
          <dt><i class="iconfont icon-live_me"></i></dt>
          <dd>我的</dd>
        </a>
      </dl>
    </div>
  </div>
  <!-- js -->
  <script src="./js/jquery.js"></script>
  <script src="./js/jquery-confirm.min.js"></script>
  <script src="./js/swiper.min.js"></script>
  <script src="./js/function.js"></script>
  <script src="./js/script.js"></script>
</body>

</html>