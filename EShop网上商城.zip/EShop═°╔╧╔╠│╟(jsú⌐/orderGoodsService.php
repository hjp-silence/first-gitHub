<?php	
ini_set("session.use_trans_sid","1");
ini_set("session.use_only_cookies",0);
ini_set("session.use_cookies",1);
session_start();	
?>
<?php include_once("./mysqli.php"); ?>
<?php include_once("./cartGoods.php"); ?>
<?php include_once("./myCart.php"); ?>
<?php
//$rs = Query("select * from tbl_goods");
$id = $_GET["id"];

$rs = Query("select * from tbl_sale_goods where sale_id=".$id);

echo json_encode($rs);
?>